/*
DynamicStringArray.cpp
Taylor Rembos
EEL3834 - Assignment 9 .cpp file
*/

#include <string>
#include "DynamicStringArray.h"
using namespace std;

//getSize function returns size
int DynamicStringArray::getSize()
{
	return size;
}

//addEntry function takes string as input
void DynamicStringArray::addEntry(string element)
{
	int i;
	string* new_dynamic_array = new string[size+1]; 
	//creates new dynamic array one element smaller than dynamicArray
	
	for(i=0; i<size; i++)
		new_dynamic_array[i] = dynamicArray[i];
		new_dynamic_array[i] = element;
		size++;
		delete[] dynamicArray;
		dynamicArray = new_dynamic_array;
}     

//deleteEntry function takes string as input
bool DynamicStringArray::deleteEntry(string input)
{
	int i;

	//search dynamicArray for string
	for(i=0; i<size; i++)
		if(dynamicArray[i].compare(input)==0)
			//found
			break;
		if(i==size)
			//not found, return false
			return false;
	
	string *new_dynamic_array = new string[size-1];
	//if found, creates new dynamic array one element smaller than dynamicArray
	int index = 0;
	for(i=0; i<size; i++){
		if(dynamicArray[i].compare(input)!=0)
		new_dynamic_array[index++] = dynamicArray[i];
	}

	delete[] dynamicArray;
	size--;
	dynamicArray = new_dynamic_array;
	return true;
}

//getEntry input method - takes integer as iniput, returns string at that index in dynamicArray
string DynamicStringArray::getEntry(int k)
{
	if(k<0 || k > size)
		return NULL; //NULL if index is out of dynamicArray's bounds
		return dynamicArray[k];
}

//Copy constructor makes copy of input object's dynamic array
DynamicStringArray::DynamicStringArray(const DynamicStringArray& other)
{
	size = other.size;
	dynamicArray = new string[size];
	
	for(int i=0; i<size; i++)
		dynamicArray[i] = other.dynamicArray[i];
}

//Operator overloading dynamic array so dynamic array properly copied to the target object
DynamicStringArray DynamicStringArray::operator==(const DynamicStringArray& other)
{
	size = other.size;
	dynamicArray = new string[size];

	for(int i=0; i<size; i++)
		dynamicArray[i] = other.dynamicArray[i];
		return *this;
}

//destructor frees up memory alloczted to dynamic memory
DynamicStringArray::~DynamicStringArray()
{
	delete[] dynamicArray;
}