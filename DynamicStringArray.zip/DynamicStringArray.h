/*
DynamicStringArray.h
Taylor Rembos
EEL3834 - Assignment 9 header
*/

#ifndef DynamicStringArray_H
#define DynamicStringArray_H
#include <string>
using namespace std;

class DynamicStringArray {
private:
	string* dynamicArray; //references dynamic array
	int size; //holds number of entries in array
//constructor
public:
	DynamicStringArray::DynamicStringArray()
	{
		dynamicArray = NULL;
		size = 0;
	}

	//member function
    int getSize(); // returns size
    void addEntry(string element);
    bool deleteEntry(string input);
    string getEntry(int k);

    DynamicStringArray(const DynamicStringArray& other); //makes copy of input object's dynamic array
    DynamicStringArray operator==(const DynamicStringArray& other); //overload assignment 
    	//operator so dynamic array properly copied to target object
    ~DynamicStringArray(); //destructor fress up memory allocated to dynamic arrary
};

#endif